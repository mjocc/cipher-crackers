# cipher-crackers

## To install

Create a virtual env and activate it
```shell
$ python -m venv env
$ source env/bin/activate
```

Install package
```shell
$ pip install .
```

## To run

Use the command `ciphertool`  
For how to use
```shell
$  ciphertool --help
```
